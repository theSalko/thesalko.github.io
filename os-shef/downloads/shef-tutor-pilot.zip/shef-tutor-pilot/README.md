# Shef Tutor Pilot — Aldin's ChatGPT Desktop

This private desktop pilot lets Aldin find mathematical problems in Shef's
library from his **own ChatGPT desktop account**. This is the approved setup
for the pilot; the private local connection runs in the desktop app rather than
ChatGPT web or mobile. It searches tags, subjects and difficulty
ratings, and retrieves problem statements, answer choices and diagram references.
It has no tools for changing the library or student records.

ChatGPT does the reasoning under the account signed in to the desktop app and
that account's usual limits. This package contains **no OpenAI API key**, never
calls a model API, and never requests model sampling. It makes authenticated
retrieval requests only to Shef's existing Supabase endpoint. Shef continues to
cover its own database/hosting costs. Use Aldin's personal account rather than
Salko's account or a shared, centrally billed workspace.

## One-time setup on Aldin's computer

Requirements: a supported ChatGPT desktop app and Node.js 22.13 or newer. Local
plugin availability depends on the installed app/account. This local pilot runs
on the computer where it is installed; it is not a web/mobile connector.

1. Extract the `shef-tutor-pilot` folder from the supplied ZIP.
2. Open a terminal in that folder. Start setup:

   ```sh
   node scripts/setup.mjs
   ```

3. When setup asks, enter your existing Shef OS email and password in the terminal. The password
   is hidden and sent directly to Shef OS authentication. This pilot accepts
   only Aldin's approved tutor account. **Never paste a password, token or
   connection file into ChatGPT.** Setup does not ask for ChatGPT credentials.
4. After setup finishes, run `node scripts/install.mjs`. Fully restart ChatGPT Desktop and sign in to **your own ChatGPT account**.
   Open **Plugins**, select the local marketplace shown by the installer, and
   install **Shef Tutor Pilot**. This is a separate, visible install/enable step;
   the terminal installer preserves your other plugins.
5. Start a new **local** chat in Work/Codex on the desktop app. In Codex, choose
   **Work in → This computer**. Choose the plugin with `@`,
   and try the prompts below. Confirm the read-only tool permission when asked.

If the desktop app cannot find `node`, rerun the installer using the working
Node executable. The installed copy pins that executable's absolute path.

## Updating an existing installation

Version 0.1.1 fixes the command-line startup check for file aliases and Windows
path differences. A successful imported bridge check does not test this startup
check: the desktop app launches the server as a separate command.

1. Extract the updated ZIP and run `node scripts/install.mjs` from its folder.
2. Fully restart the desktop app. In Plugins, uninstall and reinstall **Shef
   Tutor Pilot** from the local marketplace so its cached copy is refreshed.
3. Start a new local chat and select the plugin.

The existing connection is stored outside the package. Setup is required again
when that connection expires or is revoked.

## Try it

> Find the canonical tags for modular arithmetic. Then find five number theory
> problems with difficulty from 20 to 40, and show the first problem.

> Find ten algebra problems tagged POLYNOMIAL with difficulty from 20 to 35.

The numeric difficulty scale is 0–100. A problem's difficulty range matches when
it overlaps your requested range. Ask the tag-list tool for the catalogue's
exact tags. The search tool supports matching all or any supplied tags, a result
limit and pagination. Search results provide stable IDs for full problem lookup.

## What is stored and shared

Setup keeps one dedicated, revocable **problem-library token** in
`~/.shef-tutor-pilot/connection.json`. On macOS/Linux the folder is private
(`0700`) and the file is private (`0600`). Shef stores the token's hash. The token
expires after seven days, and access also depends on Aldin's current tutor/pilot
permission. Run `node scripts/setup.mjs` again to renew it.

The Shef OS password and temporary staff login tokens are not stored in the
connection file. The package, marketplace file and MCP messages contain no
connection secret. The local bridge adds the library token only to the HTTPS
request to Shef. It prints only JSON-RPC protocol messages to its standard output.

The problem search terms and filters go to Shef's server. Retrieved problem
content returns to the connected ChatGPT conversation and is processed under
that ChatGPT account's settings. Keep unrelated student/parent information out
of library searches. The pilot returns problem material, not customer records.

## Disconnect this computer

From the extracted or installed pilot folder, run:

```sh
node scripts/revoke.mjs
```

This revokes the dedicated library connection on Shef's server and removes the
local connection file. It does not sign you out of ChatGPT or delete other
plugins. You can disable/uninstall Shef Tutor Pilot through ChatGPT's Plugins UI.

If the service is offline, revocation leaves the local file in place so you can
retry. Salko can also revoke pilot access centrally. Expired or already revoked
credentials are safely removed locally.

## Packaging references

- [OpenAI: Package your plugin](https://developers.openai.com/plugins/build/plugins)
- [Agent Plugins MCP schema](https://agent-plugins.org/schemas/1.0.0/mcp.schema.json)

The root `plugin.json` and `mcp.json` use the portable Agent Plugins 1.0 schemas.
The installer adds one entry to the supported personal marketplace at
`~/.agents/plugins/marketplace.json` and preserves existing entries and settings.
