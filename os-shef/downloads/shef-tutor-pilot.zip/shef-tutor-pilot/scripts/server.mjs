import { homedir } from "node:os";
import { stdin, stdout, stderr } from "node:process";
import { once } from "node:events";
import {
  GATEWAY_URL,
  PilotError,
  fixedFetch,
  loadConnection,
  readJsonResponse,
  isMain,
} from "./common.mjs";

const MAX_LINE = 64 * 1024;
const VERSIONS = new Set(["2025-03-26", "2025-06-18", "2025-11-25"]);
const own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
function rpcId(message) {
  return message &&
    typeof message === "object" &&
    !Array.isArray(message) &&
    own(message, "id") &&
    (typeof message.id === "string" || Number.isSafeInteger(message.id))
    ? message.id
    : null;
}
const errorResult = (id, code, message) => ({
  jsonrpc: "2.0",
  id,
  error: { code, message },
});

/** A local stdio transport; the only network destination is the fixed Shef gateway. */
export function createBridge({ homeDir = homedir(), fetchImpl = fetch } = {}) {
  let protocolVersion = "2025-03-26";
  return async function bridgeLine(line) {
    let message;
    if (Buffer.byteLength(line, "utf8") > MAX_LINE)
      return errorResult(null, -32600, "MCP message is too large.");
    try {
      message = JSON.parse(line);
    } catch {
      return errorResult(null, -32700, "Invalid JSON.");
    }
    if (
      !message ||
      typeof message !== "object" ||
      Array.isArray(message) ||
      message.jsonrpc !== "2.0" ||
      typeof message.method !== "string"
    )
      return errorResult(
        null,
        -32600,
        "Send one JSON-RPC 2.0 request or notification.",
      );
    const hasId = own(message, "id");
    const id = rpcId(message);
    if (hasId && id === null)
      return errorResult(
        null,
        -32600,
        "Provide a string or integer request ID.",
      );
    try {
      const config = await loadConnection(homeDir);
      const response = await fixedFetch(fetchImpl, GATEWAY_URL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${config.token}`,
          Accept: "application/json, text/event-stream",
          "Content-Type": "application/json",
          "MCP-Protocol-Version": protocolVersion,
        },
        body: line,
      });
      if (!response.ok) {
        if (response.status === 401 || response.status === 403)
          throw new PilotError(
            "Your Shef pilot access is not active. Run terminal setup again or contact Shef.",
          );
        if (response.status === 429)
          throw new PilotError(
            "The library request limit was reached. Wait briefly and retry.",
          );
        throw new PilotError(
          "The Shef problem library is temporarily unavailable. Please retry.",
        );
      }
      if (!hasId) return null;
      const payload = await readJsonResponse(response);
      if (
        !payload ||
        typeof payload !== "object" ||
        Array.isArray(payload) ||
        payload.jsonrpc !== "2.0" ||
        payload.id !== id ||
        own(payload, "result") === own(payload, "error")
      )
        throw new PilotError(
          "The problem service returned an invalid MCP response.",
        );
      if (
        message.method === "initialize" &&
        VERSIONS.has(payload.result?.protocolVersion)
      )
        protocolVersion = payload.result.protocolVersion;
      return payload;
    } catch (error) {
      if (!hasId) return null;
      return errorResult(
        id,
        -32000,
        error instanceof PilotError
          ? error.message
          : "The Shef problem library could not be reached. Please retry.",
      );
    }
  };
}

/**
 * @param {{input?: import('node:stream').Readable, output?: import('node:stream').Writable, homeDir?: string, fetchImpl?: typeof fetch}} [options]
 */
export async function runStdio({
  input = stdin,
  output = stdout,
  homeDir = homedir(),
  fetchImpl = fetch,
} = {}) {
  const bridge = createBridge({ homeDir, fetchImpl });
  let buffer = "";
  let discarding = false;
  const write = async (value) => {
    if (value && !output.write(`${JSON.stringify(value)}\n`))
      await once(output, "drain");
  };
  input.setEncoding("utf8");
  for await (const chunk of input) {
    buffer += chunk;
    let newline;
    while ((newline = buffer.indexOf("\n")) !== -1) {
      const line = buffer.slice(0, newline).replace(/\r$/, "");
      buffer = buffer.slice(newline + 1);
      if (discarding) {
        discarding = false;
        continue;
      }
      if (line.trim()) await write(await bridge(line));
    }
    if (Buffer.byteLength(buffer, "utf8") > MAX_LINE) {
      if (!discarding)
        await write(errorResult(null, -32600, "MCP message is too large."));
      buffer = "";
      discarding = true;
    }
  }
  if (!discarding && buffer.trim()) await write(await bridge(buffer));
}
if (isMain(import.meta.url)) {
  runStdio().catch(() => {
    stderr.write(
      "The Shef local problem bridge stopped. Restart the chat and try again.\n",
    );
    process.exitCode = 1;
  });
}
