import { homedir } from "node:os";
import { stdout, stderr } from "node:process";
import {
  GATEWAY_URL,
  PilotError,
  fixedFetch,
  loadConnection,
  deleteConnection,
  isMain,
} from "./common.mjs";

export async function revokeConnection({
  homeDir = homedir(),
  fetchImpl = fetch,
} = {}) {
  const config = await loadConnection(homeDir, { requireUnexpired: false });
  const response = await fixedFetch(fetchImpl, `${GATEWAY_URL}/revoke`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${config.token}`,
      "Content-Type": "application/json",
    },
    body: "{}",
  });
  // Expired/revoked access is already unusable. Other failures keep the local
  // token available so the tutor can retry actual server-side revocation.
  if (!response.ok && response.status !== 401)
    throw new PilotError(
      "The service could not revoke access. The local connection was kept; try again.",
    );
  await deleteConnection(homeDir);
  return { revoked: true };
}
if (isMain(import.meta.url)) {
  revokeConnection()
    .then(() =>
      stdout.write(
        "This computer's problem-library connection was revoked and removed.\n",
      ),
    )
    .catch((error) => {
      stderr.write(
        `${error instanceof PilotError ? error.message : "Revocation could not finish. Try again."}\n`,
      );
      process.exitCode = 1;
    });
}
