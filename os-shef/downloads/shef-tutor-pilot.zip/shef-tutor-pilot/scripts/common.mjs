import {
  lstat,
  mkdir,
  open,
  readFile,
  rename,
  chmod,
  unlink,
} from "node:fs/promises";
import { constants } from "node:fs";
import { homedir } from "node:os";
import { join, resolve } from "node:path";
import { randomBytes } from "node:crypto";
import { fileURLToPath } from "node:url";

export const SUPABASE_URL = "https://xaruzwjznuavzdmoutdp.supabase.co";
export const GATEWAY_URL = `${SUPABASE_URL}/functions/v1/tutor-problems-mcp`;
export const ALDIN_EMAIL = "aldin.adilovic97@gmail.com";
export const PLUGIN_NAME = "shef-tutor-pilot";
export const TOKEN_PATTERN = /^shef_pl_[0-9a-f]{64}$/;
const UUID =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export class PilotError extends Error {}
export function isMain(metaUrl) {
  return process.argv[1] && fileURLToPath(metaUrl) === resolve(process.argv[1]);
}
export function connectionPaths(homeDir = homedir()) {
  const directory = join(resolve(homeDir), ".shef-tutor-pilot");
  return { directory, file: join(directory, "connection.json") };
}
async function regularPath(path, kind) {
  try {
    const stat = await lstat(path);
    if (
      stat.isSymbolicLink() ||
      (kind === "directory" ? !stat.isDirectory() : !stat.isFile())
    )
      throw new PilotError(
        "The pilot configuration path must be a regular file or directory.",
      );
    return stat;
  } catch (error) {
    if (error?.code === "ENOENT") return null;
    throw error;
  }
}
export function validateConnection(
  value,
  { requireUnexpired = true, now = Date.now() } = {},
) {
  if (
    !value ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    Object.keys(value).some(
      (key) => !["token", "expires_at", "token_id"].includes(key),
    ) ||
    !TOKEN_PATTERN.test(value.token ?? "") ||
    !UUID.test(value.token_id ?? "") ||
    typeof value.expires_at !== "string" ||
    !Number.isFinite(Date.parse(value.expires_at))
  )
    throw new PilotError(
      "The pilot connection is invalid. Run the terminal setup again.",
    );
  if (requireUnexpired && Date.parse(value.expires_at) <= now)
    throw new PilotError(
      "The pilot connection expired. Run the terminal setup again.",
    );
  return {
    token: value.token,
    expires_at: value.expires_at,
    token_id: value.token_id,
  };
}
export async function loadConnection(homeDir, options) {
  const paths = connectionPaths(homeDir);
  const directory = await regularPath(paths.directory, "directory");
  const stat = await regularPath(paths.file, "file");
  if (!directory || !stat)
    throw new PilotError(
      "Connect this computer first: run node scripts/setup.mjs in the pilot folder.",
    );
  if (
    process.platform !== "win32" &&
    (directory.mode & 0o077 || stat.mode & 0o077)
  )
    throw new PilotError(
      "The pilot connection file is not private. Run the terminal setup again.",
    );
  if (stat.size > 4096)
    throw new PilotError("The pilot connection is invalid. Run setup again.");
  let value;
  try {
    value = JSON.parse(await readFile(paths.file, "utf8"));
  } catch {
    throw new PilotError("The pilot connection is invalid. Run setup again.");
  }
  return validateConnection(value, options);
}
export async function saveConnection(homeDir, value) {
  const valid = validateConnection(value);
  const paths = connectionPaths(homeDir);
  const directory = await regularPath(paths.directory, "directory");
  if (!directory)
    await mkdir(paths.directory, { mode: 0o700, recursive: true });
  await regularPath(paths.file, "file");
  await chmod(paths.directory, 0o700);
  const temp = join(
    paths.directory,
    `.connection-${randomBytes(8).toString("hex")}.tmp`,
  );
  let handle;
  try {
    handle = await open(
      temp,
      constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL,
      0o600,
    );
    await handle.writeFile(`${JSON.stringify(valid, null, 2)}\n`);
    await handle.close();
    handle = null;
    await rename(temp, paths.file);
    await chmod(paths.file, 0o600);
  } finally {
    await handle?.close();
    await unlink(temp).catch((error) => {
      if (error.code !== "ENOENT") throw error;
    });
  }
  return valid;
}
export async function deleteConnection(homeDir) {
  const { file } = connectionPaths(homeDir);
  await regularPath(file, "file");
  await unlink(file).catch((error) => {
    if (error.code !== "ENOENT") throw error;
  });
}
export async function readJsonResponse(response, maximumBytes = 2_100_000) {
  if (!response.body)
    throw new PilotError("The problem service returned an empty response.");
  const reader = response.body.getReader();
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maximumBytes) {
        await reader.cancel();
        throw new PilotError("The problem service response was too large.");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new PilotError("The problem service returned an invalid response.");
  }
}
export async function fixedFetch(fetchImpl, path, init = {}) {
  const url = new URL(path, `${GATEWAY_URL}/`);
  if (
    url.origin !== SUPABASE_URL ||
    !(
      url.pathname === "/functions/v1/tutor-problems-mcp" ||
      url.pathname.startsWith("/functions/v1/tutor-problems-mcp/")
    )
  )
    throw new PilotError("Invalid pilot service destination.");
  return fetchImpl(url.href, {
    ...init,
    redirect: "error",
    signal: AbortSignal.timeout(25_000),
  });
}
