import { createHash, randomBytes } from "node:crypto";
import { createInterface, emitKeypressEvents } from "node:readline";
import { stdin, stdout, stderr } from "node:process";
import { homedir } from "node:os";
import {
  ALDIN_EMAIL,
  GATEWAY_URL,
  SUPABASE_URL,
  PilotError,
  fixedFetch,
  readJsonResponse,
  saveConnection,
  loadConnection,
  isMain,
} from "./common.mjs";

function publicKey(key) {
  if (typeof key !== "string") return false;
  if (/^sb_publishable_[A-Za-z0-9_-]+$/.test(key)) return true;
  try {
    return (
      JSON.parse(Buffer.from(key.split(".")[1], "base64url").toString())
        .role === "anon"
    );
  } catch {
    return false;
  }
}
export async function promptCredentials() {
  if (!stdin.isTTY || !stdout.isTTY || typeof stdin.setRawMode !== "function")
    throw new PilotError(
      "Run setup directly in a terminal so the password can be hidden.",
    );
  const rl = createInterface({ input: stdin, output: stdout });
  const email = await new Promise((resolve) =>
    rl.question(`Shef OS email [${ALDIN_EMAIL}]: `, resolve),
  );
  rl.close();
  const password = await new Promise((resolve, reject) => {
    let value = "";
    const previousRaw = stdin.isRaw;
    emitKeypressEvents(stdin);
    stdout.write("Shef OS password (hidden): ");
    stdin.setRawMode(true);
    stdin.resume();
    const cleanup = () => {
      stdin.off("keypress", onKey);
      stdin.setRawMode(previousRaw ?? false);
      stdin.pause();
      stdout.write("\n");
    };
    function onKey(text, key = {}) {
      if ((key.ctrl && key.name === "c") || key.name === "escape") {
        cleanup();
        reject(new PilotError("Setup cancelled."));
      } else if (key.name === "return" || key.name === "enter") {
        cleanup();
        resolve(value);
      } else if (key.name === "backspace")
        value = [...value].slice(0, -1).join("");
      else if (
        !key.ctrl &&
        !key.meta &&
        text &&
        !/[\u0000-\u001f\u007f]/u.test(text)
      ) {
        if (value.length < 1024) value += text;
      }
    }
    stdin.on("keypress", onKey);
  });
  return { email: String(email).trim() || ALDIN_EMAIL, password };
}

/** Intended to run locally on Aldin's computer. No credentials are logged. */
export async function setupConnection({
  homeDir = homedir(),
  fetchImpl = fetch,
  credentials = promptCredentials,
} = {}) {
  const infoResponse = await fixedFetch(fetchImpl, `${GATEWAY_URL}/setup-info`);
  if (!infoResponse.ok)
    throw new PilotError("The pilot is not ready for setup. Contact Shef.");
  const info = await readJsonResponse(infoResponse, 10_000);
  if (info.supabase_url !== SUPABASE_URL || !publicKey(info.publishable_key))
    throw new PilotError(
      "The pilot setup configuration could not be verified.",
    );
  let previous;
  try {
    previous = await loadConnection(homeDir, { requireUnexpired: false });
  } catch {
    /* A fresh setup also repairs expired or invalid local configuration. */
  }
  let login = await credentials();
  if (
    !login ||
    typeof login.email !== "string" ||
    login.email.trim().toLowerCase() !== ALDIN_EMAIL ||
    typeof login.password !== "string" ||
    !login.password ||
    login.password.length > 1024
  )
    throw new PilotError(
      "This pilot is available only to Aldin's existing Shef OS account.",
    );
  let session;
  let token;
  try {
    const auth = await fetchImpl(
      `${SUPABASE_URL}/auth/v1/token?grant_type=password`,
      {
        method: "POST",
        redirect: "error",
        signal: AbortSignal.timeout(25_000),
        headers: {
          apikey: info.publishable_key,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email: ALDIN_EMAIL, password: login.password }),
      },
    );
    login.password = "";
    login = null;
    if (!auth.ok)
      throw new PilotError(
        "Shef OS sign-in failed. Check your email and password.",
      );
    session = await readJsonResponse(auth, 40_000);
    if (typeof session.access_token !== "string" || !session.access_token)
      throw new PilotError("Shef OS sign-in did not return a valid session.");
    token = `shef_pl_${randomBytes(32).toString("hex")}`;
    const tokenHash = createHash("sha256").update(token).digest("hex");
    const minted = await fetchImpl(
      `${SUPABASE_URL}/rest/v1/rpc/create_tutor_problem_library_token`,
      {
        method: "POST",
        redirect: "error",
        signal: AbortSignal.timeout(25_000),
        headers: {
          apikey: info.publishable_key,
          Authorization: `Bearer ${session.access_token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          p_token_hash: tokenHash,
          p_label: "ChatGPT Desktop pilot",
        }),
      },
    );
    if (!minted.ok)
      throw new PilotError(
        "This Shef OS account does not have active pilot access. Contact Shef.",
      );
    const data = await readJsonResponse(minted, 10_000);
    const connection = {
      token,
      token_id: data.id,
      expires_at: data.expires_at,
    };
    try {
      await saveConnection(homeDir, connection);
    } catch (error) {
      // A token that failed to reach local storage should not remain usable.
      await fixedFetch(fetchImpl, `${GATEWAY_URL}/revoke`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: "{}",
      }).catch(() => {});
      throw error;
    }
    if (previous && previous.token !== token) {
      await fixedFetch(fetchImpl, `${GATEWAY_URL}/revoke`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${previous.token}`,
          "Content-Type": "application/json",
        },
        body: "{}",
      }).catch(() => {});
    }
    return { expires_at: connection.expires_at };
  } finally {
    if (session?.access_token) {
      // Close this one-time login's refresh session; no staff JWT is stored.
      await fetchImpl(`${SUPABASE_URL}/auth/v1/logout?scope=local`, {
        method: "POST",
        redirect: "error",
        signal: AbortSignal.timeout(10_000),
        headers: {
          apikey: info.publishable_key,
          Authorization: `Bearer ${session.access_token}`,
        },
      }).catch(() => {});
    }
    if (login) login.password = "";
    login = null;
    session = null;
    token = null;
  }
}

if (isMain(import.meta.url)) {
  stdout.write(
    "Shef Tutor Pilot setup\nUse your existing Shef OS credentials here in this terminal. Never paste your password or connection file into a chat.\n",
  );
  setupConnection()
    .then(({ expires_at }) => {
      stdout.write(
        `Connected. This computer's library access expires ${expires_at}.\nSign in to your OWN ChatGPT desktop account, install Shef Tutor Pilot, and start a new chat.\nThe bridge uses no OpenAI API key or model API calls. Your ChatGPT account handles its own usage.\n`,
      );
    })
    .catch((error) => {
      stderr.write(
        `${error instanceof PilotError ? error.message : "Setup could not finish. Check your connection and try again."}\n`,
      );
      process.exitCode = 1;
    });
}
