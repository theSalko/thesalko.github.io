import { cp, lstat, mkdir, readFile, rename, open, rm } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join, resolve, relative, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { randomBytes } from "node:crypto";
import { stdout, stderr } from "node:process";
import { PilotError, PLUGIN_NAME, isMain } from "./common.mjs";

const object = (value) =>
  value !== null && typeof value === "object" && !Array.isArray(value);
async function safeDirectory(path) {
  try {
    const stat = await lstat(path);
    if (!stat.isDirectory() || stat.isSymbolicLink())
      throw new PilotError(
        "The installation path must be a regular directory.",
      );
  } catch (error) {
    if (error?.code !== "ENOENT") throw error;
    await mkdir(path, { recursive: true });
  }
}
async function readMarketplace(file) {
  try {
    const stat = await lstat(file);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 2_000_000)
      throw new PilotError(
        "The existing plugin marketplace is not a regular catalogue file.",
      );
    const value = JSON.parse(await readFile(file, "utf8"));
    if (
      !object(value) ||
      typeof value.name !== "string" ||
      !value.name ||
      !Array.isArray(value.plugins)
    )
      throw new Error("Invalid marketplace shape");
    return value;
  } catch (error) {
    if (error?.code === "ENOENT")
      return {
        name: "shef-personal-pilot",
        interface: { displayName: "Shef personal pilot" },
        plugins: [],
      };
    if (error instanceof PilotError) throw error;
    throw new PilotError(
      "The existing plugin marketplace is invalid. It was left unchanged.",
    );
  }
}
async function rejectSymlinks(path) {
  const { readdir } = await import("node:fs/promises");
  for (const entry of await readdir(path, { withFileTypes: true })) {
    const child = join(path, entry.name);
    if (entry.isSymbolicLink())
      throw new PilotError("Plugin packages must not contain symbolic links.");
    if (entry.isDirectory()) await rejectSymlinks(child);
  }
}
export async function installPilot({
  homeDir = homedir(),
  sourceDir = resolve(dirname(fileURLToPath(import.meta.url)), ".."),
  nodeExecutable = process.execPath,
} = {}) {
  const home = resolve(homeDir);
  const agents = join(home, ".agents");
  const marketplaceRoot = join(agents, "plugins");
  const destination = join(marketplaceRoot, PLUGIN_NAME);
  const file = join(marketplaceRoot, "marketplace.json");
  await safeDirectory(home);
  await safeDirectory(agents);
  await safeDirectory(marketplaceRoot);
  await safeDirectory(destination);
  const marketplace = await readMarketplace(file);
  const manifest = JSON.parse(
    await readFile(join(sourceDir, "plugin.json"), "utf8"),
  );
  if (manifest.name !== PLUGIN_NAME)
    throw new PilotError("This is not the Shef Tutor Pilot package.");
  await rejectSymlinks(sourceDir);
  if (resolve(sourceDir) !== destination) {
    await rejectSymlinks(destination);
    await cp(sourceDir, destination, {
      recursive: true,
      force: true,
      dereference: false,
    });
  }
  const mcp = JSON.parse(await readFile(join(destination, "mcp.json"), "utf8"));
  // GUI apps may have a shorter PATH than the terminal. Pin the Node executable
  // used for this installation; the distributed package remains portable.
  mcp.mcpServers["shef-problems"].command = nodeExecutable;
  await (
    await import("node:fs/promises")
  ).writeFile(
    join(destination, "mcp.json"),
    `${JSON.stringify(mcp, null, 2)}\n`,
  );
  const path = `./${relative(home, destination).split(sep).join("/")}`;
  const existing = marketplace.plugins.find(
    (entry) => entry?.name === PLUGIN_NAME,
  );
  const updated = {
    ...(object(existing) ? existing : {}),
    name: PLUGIN_NAME,
    source: { source: "local", path },
    policy: {
      ...(object(existing?.policy) ? existing.policy : {}),
      installation: "AVAILABLE",
      authentication: "ON_INSTALL",
    },
    category: "Education",
  };
  const catalog = {
    ...marketplace,
    plugins: [
      ...marketplace.plugins.filter((entry) => entry?.name !== PLUGIN_NAME),
      updated,
    ],
  };
  const temporary = join(
    marketplaceRoot,
    `.marketplace-${randomBytes(8).toString("hex")}.tmp`,
  );
  let handle;
  try {
    handle = await open(temporary, "wx", 0o600);
    await handle.writeFile(`${JSON.stringify(catalog, null, 2)}\n`);
    await handle.close();
    handle = null;
    await rename(temporary, file);
  } finally {
    await handle?.close();
    await rm(temporary, { force: true });
  }
  return { plugin_directory: destination, marketplace: catalog.name };
}
if (isMain(import.meta.url)) {
  installPilot()
    .then(({ plugin_directory, marketplace }) => {
      stdout.write(
        `Installed package at ${plugin_directory}\nMarketplace: ${marketplace}\nRestart ChatGPT Desktop. In Plugins, choose this local marketplace and install Shef Tutor Pilot. Use your OWN ChatGPT account.\nRun node scripts/setup.mjs in the extracted pilot folder to connect your Shef OS account.\n`,
      );
    })
    .catch((error) => {
      stderr.write(
        `${error instanceof PilotError ? error.message : "Installation could not finish. Existing plugin settings were preserved."}\n`,
      );
      process.exitCode = 1;
    });
}
